# Resurface (frontend)
React + TypeScript + Tailwind + Vite. Runs on clearly labeled example data by default.

## Run (Windows, VS Code)
1. Extract the ZIP. Open the inner `resurface` folder in VS Code (File > Open Folder). Confirm you see `package.json` in the left panel.
2. Terminal > New Terminal, then run `npm.cmd install` and `npm.cmd run dev`.
3. Open the http://localhost:5173 link shown. Edit files in `src/`; the page updates when you save.
4. Check types/build: `npm.cmd run build`.

## Structure
`src/pages` screens · `src/components` UI · `src/services/api.ts` ALL data access · `src/services/scoring.ts` Revival Score · `src/data/mock.ts` example data · `src/types` shared contracts.

## Mock vs live
Copy `.env.example` to `.env`, set `VITE_DATA_MODE=live` and `VITE_API_BASE_URL`. Restart `npm.cmd run dev`.

See `API_GUIDE.md` for endpoints.
