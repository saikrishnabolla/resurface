// Shared contracts. Backend teammates: return JSON matching these shapes. See API_GUIDE.md.
export interface Source { title: string; publisher: string; date: string; url?: string }
export interface Topic { id: string; name: string; description: string; category: string; trending: boolean; relevantToCreator: boolean; momentum?: 'rising' | 'steady' | 'emerging'; sources: Source[] }
export interface TranscriptSegment { start: number; text: string }
export interface Video { id: string; title: string; publishedAt: string; durationSec: number; transcript: TranscriptSegment[]; url?: string }
export interface CreatorProfile { name: string; channelUrl: string; role: string; subjects: string[] }
export interface ScoreParts { relevance: number; momentum: number; quality: number; freshness: number } // each 0-100
export interface Clip { id: string; trendId: string; videoId: string; start: number; end: number; excerpt: string; why: string; scores: ScoreParts; hooks: string[] }
export type Layout = 'split' | 'full' | 'overlay'
export type CaptionStyle = 'bold' | 'minimal' | 'dynamic'
export interface GenerationRequest { clipId: string; start: number; end: number; layout: Layout; captionStyle: CaptionStyle; captionPosition: 'top' | 'middle' | 'bottom'; hook: string; headline: string; sources: Source[] }
export type QueueStatus = 'saved' | 'review' | 'approved' | 'rendering' | 'completed'
export interface QueueItem { clipId: string; status: QueueStatus; addedAt: string; request?: GenerationRequest; videoUrl?: string }
export interface Settings { channelUrl: string; topics: string[]; editingStyle: string; captionStyle: CaptionStyle; tone: string }
