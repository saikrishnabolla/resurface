import { Link } from 'react-router-dom'
import { Loader2, AlertTriangle, Inbox } from 'lucide-react'
import type { ReactNode } from 'react'
import type { Clip, Video, Topic } from '../types'
import { revivalScore } from '../services/scoring'
export const fmt = (s: number) => `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, '0')}`
export const fdate = (d: string) => new Date(d).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' })
export const Header = ({ title, sub, right, kicker }: { title: string; sub?: string; right?: ReactNode; kicker?: string }) => (
  <div className="flex items-end justify-between gap-4 mb-10"><div>{kicker && <div className="label !text-emerald mb-3">{kicker}</div>}
    <h1 className="text-5xl md:text-7xl font-semibold tracking-tight leading-[0.95]">{title}</h1>{sub && <p className="text-mute mt-4 max-w-xl">{sub}</p>}</div>{right}</div>)
export const Loading = () => <div className="flex items-center gap-2 text-mute py-12"><Loader2 className="animate-spin" size={16} />Loading</div>
export const ErrorBox = ({ msg, retry }: { msg: string; retry?: () => void }) => (
  <div className="border border-line bg-surface p-5 flex items-center gap-3"><AlertTriangle size={18} className="text-emerald" /><div className="flex-1"><b>Something went wrong.</b><div className="text-mute">{msg}</div></div>{retry && <button className="btn" onClick={retry}>Retry</button>}</div>)
export const Empty = ({ text }: { text: string }) => <div className="border border-dashed border-line p-10 text-center text-mute"><Inbox className="mx-auto mb-2" size={20} />{text}</div>
export const DemoTag = () => <span className="label !text-emerald border border-emerald px-1.5 py-0.5">Demo data</span>
export const Score = ({ clip }: { clip: Clip }) => <div className="text-right w-16 shrink-0"><div className="text-3xl font-semibold text-emerald leading-none">{revivalScore(clip.scores)}</div><div className="label !text-[10px] mt-1">Revival</div></div>
export const Thumb = ({ title, className = '' }: { title: string; className?: string }) => (
  <div className={`bg-surface border border-line flex items-center justify-center ${className}`} title={title}><svg width="26" viewBox="0 0 24 24"><path d="M7 4v16l13-8z" fill="#7BDDB0" /></svg></div>)
export function ClipRow({ clip, video, topic }: { clip: Clip; video?: Video; topic?: Topic }) {
  return (<div className="flex gap-5 py-5 border-b border-line items-start">
    <Thumb title={video?.title ?? ''} className="w-40 aspect-video shrink-0 hidden sm:flex" />
    <div className="flex-1 min-w-0"><div className="label">{video && fdate(video.publishedAt)} · from {fmt(clip.start)} · {clip.end - clip.start}s{topic && ` · ${topic.name}`}</div>
      <div className="text-lg font-semibold mt-1">{video?.title}</div><p className="text-mute mt-1">{clip.why}</p></div>
    <Score clip={clip} /><Link to={`/review/${clip.id}`} className="btn">Review</Link></div>)
}
