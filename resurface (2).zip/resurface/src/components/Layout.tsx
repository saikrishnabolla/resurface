import { Link, NavLink, Outlet } from 'react-router-dom'
import { Logo } from '../assets/Logo'
import { MODE } from '../services/api'
const nav = [['/', 'Discover'], ['/archive', 'Archive'], ['/review', 'Review'], ['/studio', 'Studio'], ['/queue', 'Queue']]
export default function Layout() {
  return (<div className="min-h-screen md:flex">
    <aside className="md:w-60 md:fixed md:inset-y-0 border-b md:border-b-0 md:border-r border-line p-6 flex md:flex-col gap-8 overflow-x-auto">
      <Link to="/"><Logo /></Link>
      <nav className="flex md:flex-col gap-1">{nav.map(([to, label], i) => (
        <NavLink key={to} to={to} end={to === '/'} className={({ isActive }) => `flex items-baseline gap-3 py-2 pl-3 border-l-2 whitespace-nowrap ${isActive ? 'border-emerald text-emerald' : 'border-transparent text-mute hover:text-ink'}`}>
          <span className="label !text-[10px]">0{i + 1}</span><span className="text-base font-medium">{label}</span></NavLink>))}</nav>
      <div className="md:mt-auto hidden md:block border-t border-line pt-4"><div className="label mb-1">Creator</div><div className="font-medium">Kameron Monet</div><div className="text-mute text-xs">Attorney · Social Docket</div>
        <div className="label !text-emerald mt-4">{MODE === 'mock' ? 'Demo data' : 'Live data'}</div></div>
    </aside>
    <main className="flex-1 md:ml-60 px-6 md:px-14 py-10 max-w-[1200px]">
      {MODE === 'mock' && <p className="label mb-10 border-b border-line pb-3">Demo mode · all videos, news and scores are example data</p>}
      <Outlet /></main></div>)
}
