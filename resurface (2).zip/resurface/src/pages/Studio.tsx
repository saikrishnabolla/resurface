import { useEffect, useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import { getClip, getClips, getTopics, getVideos, submitGeneration } from '../services/api'
import { useAsync, useQueue } from '../hooks/hooks'
import { Header, Loading, ErrorBox, Empty, fmt } from '../components/ui'
import type { CaptionStyle, Layout } from '../types'
function Seg<T extends string>({ v, set, opts }: { v: T; set: (x: T) => void; opts: [T, string][] }) {
  return <div className="flex border border-line  overflow-hidden">{opts.map(([k, l]) => <button key={k} onClick={() => set(k)} className={`flex-1 text-sm font-bold py-2.5 ${v === k ? 'bg-emerald text-cream' : 'bg-surface'}`}>{l}</button>)}</div>
}
export default function Studio() {
  const { id } = useParams(); const qu = useQueue(); const all = useAsync(() => getClips(), []); const topics = useAsync(getTopics, []); const vids = useAsync(getVideos, [])
  const one = useAsync(() => id ? getClip(id) : Promise.resolve(undefined), [id])
  const [layout, setLayout] = useState<Layout>('split'); const [cap, setCap] = useState<CaptionStyle>('bold'); const [pos, setPos] = useState<'top' | 'middle' | 'bottom'>('bottom')
  const [hook, setHook] = useState(''); const [headline, setHeadline] = useState(''); const [s, setS] = useState(0); const [e, setE] = useState(30); const [msg, setMsg] = useState('')
  const clip = one.data; const topic = topics.data?.find(t => t.id === clip?.trendId)
  useEffect(() => { if (clip) { setS(clip.start); setE(clip.end); setHook(clip.hooks[0]); setHeadline(topic?.sources[0]?.title ?? '') } }, [clip?.id, topic?.id]) // eslint-disable-line
  if (!id) return <><Header kicker="04 / Studio" title="Studio" sub="Pick a clip to customize." />{all.loading ? <Loading /> : all.data?.length ? <div className="grid sm:grid-cols-2 gap-2">{all.data.map(c => <Link key={c.id} to={`/studio/${c.id}`} className="btn">{vids.data?.find(v => v.id === c.videoId)?.title} · {fmt(c.start)}</Link>)}</div> : <Empty text="No clips." />}</>
  if (one.loading) return <Loading />
  if (one.error || !clip) return <ErrorBox msg={one.error ?? 'Clip not found'} />
  const gen = async () => { const req = { clipId: clip.id, start: s, end: e, layout, captionStyle: cap, captionPosition: pos, hook, headline, sources: topic?.sources ?? [] }
    try { const r = await submitGeneration(req); const saved = r.status === 'request-saved-not-rendered'; qu.add(clip.id, saved ? 'approved' : 'rendering', { request: req }); setMsg(saved ? 'Generation request saved to the queue. No video was rendered (backend generator not connected).' : 'Sent to the video generator.') } catch (x) { setMsg('Failed: ' + (x as Error).message) } }
  const capCls = { bold: 'font-semibold tracking-tight text-xl uppercase', minimal: 'text-sm', dynamic: 'font-bold text-lg italic text-emerald' }[cap]
  const capPos = { top: 'top-4', middle: 'top-1/2', bottom: 'bottom-6' }[pos]
  return (<><Header kicker="04 / Studio" title="Resurface Studio" sub={vids.data?.find(v => v.id === clip.videoId)?.title} right={<Link to={`/review/${clip.id}`} className="btn">Back to review</Link>} />
    <div className="grid md:grid-cols-5 gap-8"><div className="md:col-span-2 flex justify-center"><div className="relative bg-forest w-64 aspect-[9/16] overflow-hidden text-ink border border-line ">
      {layout === 'split' && <><div className="absolute inset-x-0 top-0 h-1/2 bg-emerald text-cream flex items-center justify-center text-xs">Original footage</div><div className="absolute inset-x-0 bottom-0 h-1/2 bg-surface text-ink p-3 text-xs pt-8"><b>{topic?.sources[0]?.publisher}</b><br />{headline}</div></>}
      {layout === 'full' && <div className="absolute inset-0 bg-emerald text-cream flex items-center justify-center text-xs">Original footage</div>}
      {layout === 'overlay' && <><div className="absolute inset-0 bg-emerald text-cream flex items-center justify-center text-xs">Original footage</div><div className="absolute top-4 inset-x-3 bg-surface text-ink p-2 text-xs">{headline}</div></>}
      <div className={`absolute inset-x-3 text-center ${capPos} ${capCls}`}>{hook}</div><div className="absolute bottom-1 right-2 text-[9px] opacity-70">{fmt(e - s)}</div></div></div>
    <div className="md:col-span-3 space-y-4"><div><div className="label mb-1">Layout</div><Seg v={layout} set={setLayout} opts={[['split', 'Split screen'], ['full', 'Full footage'], ['overlay', 'News overlay']]} /></div>
      <div><div className="label mb-1">Captions</div><Seg v={cap} set={setCap} opts={[['bold', 'Bold'], ['minimal', 'Minimal'], ['dynamic', 'Dynamic']]} /></div>
      <div><div className="label mb-1">Caption position</div><Seg v={pos} set={setPos} opts={[['top', 'Top'], ['middle', 'Middle'], ['bottom', 'Bottom']]} /></div>
      <div><div className="label mb-1">Opening hook</div><div className="flex gap-1 flex-wrap mb-2">{clip.hooks.map((h, i) => <button key={i} className="btn !py-1 !text-xs" onClick={() => setHook(h)}>Option {i + 1}</button>)}</div><textarea className="input" rows={2} value={hook} onChange={x => setHook(x.target.value)} /></div>
      <div><div className="label mb-1">Headline</div><input className="input" value={headline} onChange={x => setHeadline(x.target.value)} /></div>
      <div className="grid grid-cols-2 gap-3"><label className="label">Start ({fmt(s)})<input type="range" className="w-full accent-emerald" min={0} max={Math.max(e - 5, 0)} value={s} onChange={x => setS(+x.target.value)} /></label>
        <label className="label">End ({fmt(e)})<input type="range" className="w-full accent-emerald" min={s + 5} max={s + 90} value={e} onChange={x => setE(+x.target.value)} /></label></div>
      <button className="btn btn-primary" onClick={gen}>Generate Video</button>{msg && <p className="text-sm text-mute">{msg} <Link to="/queue" className="underline">Open queue</Link></p>}</div></div></>)
}
