import { useState } from 'react'
import { Link } from 'react-router-dom'
import { Trash2, ArrowUp, ArrowDown } from 'lucide-react'
import { getClips, getVideos } from '../services/api'
import { useAsync, useQueue } from '../hooks/hooks'
import { Header, Loading, Empty, fdate, fmt } from '../components/ui'
import type { QueueStatus } from '../types'
const STATUSES: [QueueStatus, string][] = [['saved', 'Saved'], ['review', 'Draft'], ['approved', 'Approved'], ['rendering', 'Rendering'], ['completed', 'Completed']]
export default function Queue() {
  const { queue, remove, setStatus, move } = useQueue(); const [q, setQ] = useState(''); const [sort, setSort] = useState('manual'); const [show, setShow] = useState<string>()
  const c = useAsync(() => getClips(), []); const v = useAsync(getVideos, [])
  if (c.loading) return <Loading />
  const rows = queue.map(i => { const cl = c.data?.find(x => x.id === i.clipId); return { i, cl, vid: v.data?.find(y => y.id === cl?.videoId) } })
    .filter(r => (r.vid?.title ?? '').toLowerCase().includes(q.toLowerCase())).sort((a, b) => sort === 'manual' ? 0 : sort === 'new' ? b.i.addedAt.localeCompare(a.i.addedAt) : (a.vid?.title ?? '').localeCompare(b.vid?.title ?? ''))
  return (<><Header kicker="05 / Queue" title="Publishing Queue" sub="Saved in this browser (demo). Swap storage for a backend in services/api.ts." />
    <div className="flex gap-2 mb-5"><input className="input" placeholder="Search queue" value={q} onChange={e => setQ(e.target.value)} /><select className="input !w-auto" value={sort} onChange={e => setSort(e.target.value)}><option value="manual">Manual order</option><option value="new">Newest</option><option value="title">Title</option></select></div>
    {rows.length === 0 ? <Empty text="Queue is empty. Save a clip from Discover or Clip Review." /> : <div className="space-y-3">{rows.map(({ i, cl, vid }) => (
      <div key={i.clipId} className="bg-surface border border-line   p-4"><div className="flex flex-wrap gap-3 items-center"><div className="flex-1"><div className="font-medium">{vid?.title}</div><div className="text-xs text-mute">{cl && `${fmt(cl.start)}–${fmt(cl.end)}`} · added {fdate(i.addedAt)}</div></div>
        <select className="input !w-auto" value={i.status} onChange={e => setStatus(i.clipId, e.target.value as QueueStatus)}>{STATUSES.map(([k, l]) => <option key={k} value={k}>{l}</option>)}</select>
        <Link className="btn" to={`/studio/${i.clipId}`}>Edit</Link><button className="btn" onClick={() => setShow(show === i.clipId ? undefined : i.clipId)}>Settings</button><button className="btn" onClick={() => move(i.clipId, -1)} aria-label="Move up"><ArrowUp size={15} /></button><button className="btn" onClick={() => move(i.clipId, 1)} aria-label="Move down"><ArrowDown size={15} /></button>{i.videoUrl && <a className="btn" href={i.videoUrl} download>Download</a>}<button className="btn" onClick={() => remove(i.clipId)} aria-label="Remove"><Trash2 size={15} /></button></div>
        {show === i.clipId && <pre className="mt-3 bg-cream p-3 text-xs overflow-auto">{i.request ? JSON.stringify(i.request, null, 2) : 'No generation settings yet. Open in Studio.'}</pre>}</div>))}</div>}</>)
}
