import { useState } from 'react'
import { getClips, getTopics, getVideos } from '../services/api'
import { useAsync } from '../hooks/hooks'
import { Header, Loading, ErrorBox, Empty, ClipRow } from '../components/ui'
import { revivalScore } from '../services/scoring'
export default function Discover() {
  const [sel, setSel] = useState('t1'); const [sort, setSort] = useState('score'); const [min, setMin] = useState(0)
  const t = useAsync(getTopics, []); const v = useAsync(getVideos, []); const c = useAsync(() => getClips(sel), [sel])
  const topic = t.data?.find(x => x.id === sel)
  const date = (id: string) => v.data?.find(y => y.id === id)?.publishedAt ?? ''
  const list = (c.data ?? []).filter(x => revivalScore(x.scores) >= min).sort((a, b) => sort === 'score' ? revivalScore(b.scores) - revivalScore(a.scores) : sort === 'date' ? date(b.videoId).localeCompare(date(a.videoId)) : (a.end - a.start) - (b.end - b.start))
  return (<><Header kicker="01 / Discover" title="What's worth revisiting?" sub="Moments in your archive that today's news has made relevant again." />
    {t.error && <ErrorBox msg={t.error} retry={t.retry} />}
    <div className="border-t border-line mb-12">{t.data?.filter(x => x.relevantToCreator).map((x, i) => (
      <button key={x.id} onClick={() => setSel(x.id)} className="w-full flex items-baseline gap-5 py-4 border-b border-line text-left">
        <span className="label w-6">0{i + 1}</span>
        <span className={`text-3xl md:text-4xl font-semibold tracking-tight ${sel === x.id ? 'text-emerald' : 'text-ink hover:text-emerald'}`}>{x.name}</span>
        {x.trending && <span className="label !text-emerald border border-emerald px-1.5 py-0.5">Trending</span>}</button>))}</div>
    <div className="flex flex-wrap items-end justify-between gap-3 mb-2">
      <h2 className="text-2xl font-semibold tracking-tight">{c.loading ? 'Searching archive' : `${list.length} clip${list.length === 1 ? '' : 's'} found for ${topic?.name ?? ''}`}</h2>
      <div className="flex gap-2"><select className="input !w-auto" value={sort} onChange={e => setSort(e.target.value)}><option value="score">Revival Score</option><option value="date">Newest video</option><option value="len">Shortest clip</option></select>
        <select className="input !w-auto" value={min} onChange={e => setMin(+e.target.value)}><option value={0}>All scores</option><option value={70}>70+</option><option value={85}>85+</option></select></div></div>
    {c.loading || v.loading ? <Loading /> : c.error ? <ErrorBox msg={c.error} retry={c.retry} /> : list.length === 0 ? <Empty text="No clips match these filters." /> :
      <div className="border-t border-line mt-4">{list.map(x => <ClipRow key={x.id} clip={x} video={v.data?.find(y => y.id === x.videoId)} />)}</div>}</>)
}
