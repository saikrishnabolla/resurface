import { useState } from 'react'
import { Link } from 'react-router-dom'
import { connectChannel, getClips, getCreator, getTopics, getVideos } from '../services/api'
import { useAsync } from '../hooks/hooks'
import { Header, Loading, ErrorBox, Empty, Thumb, fdate, fmt, DemoTag } from '../components/ui'
export default function Archive() {
  const [topic, setTopic] = useState(''); const [q, setQ] = useState(''); const [yr, setYr] = useState(''); const [open, setOpen] = useState<string>(); const [url, setUrl] = useState(''); const [scan, setScan] = useState('')
  const me = useAsync(getCreator, []); const t = useAsync(getTopics, []); const v = useAsync(getVideos, []); const c = useAsync(() => getClips(), [])
  const list = (v.data ?? []).filter(x => (!topic || (c.data ?? []).some(k => k.videoId === x.id && k.trendId === topic)) && (!yr || x.publishedAt.startsWith(yr)) && (x.title + x.transcript.map(s => s.text).join(' ')).toLowerCase().includes(q.toLowerCase()))
  const years = [...new Set((v.data ?? []).map(x => x.publishedAt.slice(0, 4)))]
  const doConnect = async () => { setScan('Scanning (demonstration)…'); try { await connectChannel(url); setScan('Demonstration scan complete. No real videos were fetched.') } catch (e) { setScan('Could not connect: ' + (e as Error).message) } }
  return (<><Header kicker="02 / Archive" title="My Archive" sub="Your connected video library, searchable by title and transcript." />
    <div className="bg-surface border border-line   p-5 mb-6"><div className="label mb-2">Connect a channel <DemoTag /></div>
      <div className="flex gap-2"><input className="input" placeholder="https://www.youtube.com/@yourchannel" value={url} onChange={e => setUrl(e.target.value)} /><button className="btn btn-primary" disabled={!url} onClick={doConnect}>Scan</button></div>
      {scan && <p className="text-sm text-mute mt-2">{scan}</p>}
      {me.data && <p className="text-sm mt-3"><b>{me.data.name}</b> · {me.data.role} · {v.data?.length ?? 0} videos indexed</p>}</div>
    <div className="flex gap-2 mb-5"><input className="input" placeholder="Search title or transcript" value={q} onChange={e => setQ(e.target.value)} />
      <select className="input !w-auto" value={yr} onChange={e => setYr(e.target.value)}><option value="">All years</option>{years.map(y => <option key={y}>{y}</option>)}</select><select className="input !w-auto" value={topic} onChange={e => setTopic(e.target.value)}><option value="">All topics</option>{t.data?.filter(x => x.relevantToCreator).map(x => <option key={x.id} value={x.id}>{x.name}</option>)}</select></div>
    {v.loading ? <Loading /> : v.error ? <ErrorBox msg={v.error} retry={v.retry} /> : list.length === 0 ? <Empty text="No videos match." /> :
    <div className="space-y-3">{list.map(x => { const m = c.data?.filter(k => k.videoId === x.id) ?? []; return (
      <div key={x.id} className="bg-surface border border-line   p-4"><div className="flex gap-4 items-center"><Thumb title={x.title} className="w-32 aspect-video  shrink-0" />
        <div className="flex-1"><div className="font-medium">{x.title}</div><div className="text-xs text-mute">{fdate(x.publishedAt)} · {fmt(x.durationSec)} · {m.length} matching clips</div></div>
        <button className="btn" onClick={() => setOpen(open === x.id ? undefined : x.id)}>{open === x.id ? 'Hide' : 'Details'}</button></div>
        {open === x.id && <div className="mt-4 border-t border-line pt-3 text-sm space-y-1">{x.transcript.map((s, i) => <div key={i}><span className="text-mute tabular-nums mr-2">{fmt(s.start)}</span>{s.text}</div>)}
          <div className="pt-2 flex gap-2 flex-wrap">{m.length ? m.map(k => <Link key={k.id} to={`/review/${k.id}`} className="btn">Clip at {fmt(k.start)}</Link>) : <span className="text-mute">No matches for this video yet.</span>}</div></div>}</div>) })}</div>}</>)
}
