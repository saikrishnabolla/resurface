import { Link, useNavigate, useParams } from 'react-router-dom'
import { Bookmark, Check, X, Sliders, ExternalLink } from 'lucide-react'
import { getClip, getClips, getTopics, getVideos } from '../services/api'
import { useAsync, useQueue } from '../hooks/hooks'
import { Header, Loading, ErrorBox, Empty, ClipRow, Thumb, fdate, fmt } from '../components/ui'
import { revivalScore, WEIGHTS } from '../services/scoring'
function ReviewOne({ id }: { id: string }) {
  const nav = useNavigate(); const qu = useQueue()
  const c = useAsync(() => getClip(id), [id]); const v = useAsync(getVideos, []); const t = useAsync(getTopics, [])
  if (c.loading) return <Loading />
  if (c.error || !c.data) return <ErrorBox msg={c.error ?? 'Not found'} retry={c.retry} />
  const clip = c.data, video = v.data?.find(x => x.id === clip.videoId), topic = t.data?.find(x => x.id === clip.trendId)
  const parts: [string, keyof typeof WEIGHTS][] = [['Content relevance', 'relevance'], ['Trend momentum', 'momentum'], ['Clip quality', 'quality'], ['Freshness', 'freshness']]
  return (<><Header kicker="03 / Review" title="Clip Review" sub={video?.title} right={<Link to="/" className="btn">Back</Link>} />
    <div className="grid lg:grid-cols-5 gap-8"><div className="lg:col-span-3 space-y-6">
      <div><Thumb title="" className="aspect-video w-full " /><p className="text-xs text-mute mt-1">Placeholder preview (example data). {video && fdate(video.publishedAt)} · {fmt(clip.start)}–{fmt(clip.end)}</p></div>
      <div><div className="label mb-1">Transcript excerpt</div><blockquote className="border-l-2 border-emerald pl-4 font-semibold tracking-tight text-lg">{clip.excerpt}</blockquote></div>
      <div><div className="label mb-1">Why it matches · trend: {topic?.name}</div><p>{clip.why}</p></div>
      <div><div className="label mb-2">News sources</div>{topic?.sources.map((s, i) => <div key={i} className="bg-surface border border-line   p-3 text-sm mb-2 flex justify-between"><span>{s.title}<br /><span className="text-xs text-mute">{s.publisher} · {fdate(s.date)}</span></span>{s.url ? <a href={s.url} target="_blank" rel="noreferrer"><ExternalLink size={15} /></a> : <span className="text-[10px] text-mute">example, no URL</span>}</div>)}</div></div>
    <div className="lg:col-span-2 space-y-6"><div className="bg-surface border border-line   p-5"><div className="flex items-baseline justify-between"><div className="label">Revival Score</div><div className="font-semibold tracking-tight text-5xl text-emerald">{revivalScore(clip.scores)}</div></div>
      <div className="mt-4 space-y-3">{parts.map(([l, k]) => <div key={k}><div className="flex justify-between text-xs"><span>{l} ({WEIGHTS[k] * 100}%)</span><span>{clip.scores[k]}</span></div><div className="h-3 border border-line  overflow-hidden bg-surface"><div className="h-full bg-emerald" style={{ width: clip.scores[k] + '%' }} /></div></div>)}</div>
      <p className="text-[11px] text-mute mt-3">Illustrative heuristic, not a predictor of performance.</p></div>
      <div><div className="label mb-2">Suggested hooks</div>{clip.hooks.map((h, i) => <div key={i} className="text-sm border border-line   bg-surface p-2.5 mb-2">{h}</div>)}</div>
      <div className="flex flex-col gap-2"><Link to={`/studio/${clip.id}`} className="btn btn-primary justify-center"><Sliders size={16} />Open in Studio</Link>
        <button className="btn justify-center" onClick={() => qu.add(clip.id, 'saved')}><Bookmark size={16} />{qu.has(clip.id) ? 'Saved to queue' : 'Save for later'}</button>
        <button className="btn justify-center" onClick={() => { qu.remove(clip.id); nav('/') }}><X size={16} />Dismiss</button></div></div></div></>)
}

export default function Review() {
  const { id } = useParams(); const c = useAsync(() => getClips(), []); const v = useAsync(getVideos, [])
  if (id) return <ReviewOne id={id} />
  return <><Header kicker="03 / Review" title="Pick a clip to review" />{c.loading ? <Loading /> : c.error ? <ErrorBox msg={c.error} retry={c.retry} /> : !c.data?.length ? <Empty text="No clips yet." /> : <div className="border-t border-line">{c.data.map(k => <ClipRow key={k.id} clip={k} video={v.data?.find(y => y.id === k.videoId)} />)}</div>}</>
}
