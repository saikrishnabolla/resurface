import type { ScoreParts } from '../types'
// Illustrative heuristic, NOT a predictor of viral performance. Replace freely.
export const WEIGHTS = { relevance: 0.4, momentum: 0.3, quality: 0.2, freshness: 0.1 }
export const revivalScore = (s: ScoreParts) =>
  Math.round(s.relevance * WEIGHTS.relevance + s.momentum * WEIGHTS.momentum + s.quality * WEIGHTS.quality + s.freshness * WEIGHTS.freshness)
