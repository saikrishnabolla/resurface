import type { Topic, Video, Clip, CreatorProfile, GenerationRequest, QueueItem, Settings } from '../types'
import { clips, creator, topics, videos } from '../data/mock'
export const MODE: 'mock' | 'live' = import.meta.env.VITE_DATA_MODE === 'live' ? 'live' : 'mock'
const BASE = import.meta.env.VITE_API_BASE_URL ?? '/api'
const wait = <T,>(v: T) => new Promise<T>(r => setTimeout(() => r(v), 350))
async function http<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(BASE + path, { headers: { 'Content-Type': 'application/json' }, ...init })
  if (!res.ok) throw new Error(`Service error ${res.status} on ${path}`)
  return res.json()
}
const ls = <T,>(k: string, d: T): T => { try { return JSON.parse(localStorage.getItem(k) ?? '') as T } catch { return d } }
// Each function: GET/POST endpoint in live mode, mock data otherwise.
export const getCreator = (): Promise<CreatorProfile> => MODE === 'live' ? http('/creator') : wait(creator)
export const connectChannel = (url: string): Promise<CreatorProfile> => MODE === 'live' ? http('/creator/connect', { method: 'POST', body: JSON.stringify({ url }) }) : wait({ ...creator, channelUrl: url })
export const getVideos = (): Promise<Video[]> => MODE === 'live' ? http('/videos') : wait(videos)
export const getTopics = (): Promise<Topic[]> => MODE === 'live' ? http('/trends') : wait(topics)
export const getClips = (trendId?: string): Promise<Clip[]> => MODE === 'live' ? http('/clips' + (trendId ? `?trendId=${trendId}` : '')) : wait(clips.filter(c => !trendId || c.trendId === trendId))
export const getClip = (id: string): Promise<Clip> => MODE === 'live' ? http(`/clips/${id}`) : wait(clips.find(c => c.id === id)).then(c => { if (!c) throw new Error('Clip not found'); return c })
export const submitGeneration = (r: GenerationRequest): Promise<{ status: string }> => MODE === 'live' ? http('/generate', { method: 'POST', body: JSON.stringify(r) }) : wait({ status: 'request-saved-not-rendered' })
// Queue + settings: localStorage in demo mode; replace with /queue and /settings endpoints later.
export const loadQueue = () => ls<QueueItem[]>('rs.queue', [])
export const storeQueue = (q: QueueItem[]) => localStorage.setItem('rs.queue', JSON.stringify(q))
export const defaultSettings: Settings = { channelUrl: creator.channelUrl, topics: ['t1', 't3'], editingStyle: 'Clean, news-forward', captionStyle: 'bold', tone: 'Authoritative' }
export const loadSettings = () => ls<Settings>('rs.settings', defaultSettings)
export const storeSettings = (s: Settings) => localStorage.setItem('rs.settings', JSON.stringify(s))
