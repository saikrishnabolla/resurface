export function LogoIcon({ size = 32 }: { size?: number }) {
  return (<svg width={size} height={size} viewBox="0 0 48 48" role="img" aria-label="resurface"><rect x="3" y="10" width="42" height="22" rx="11" fill="#7BDDB0"/><circle cx="15" cy="21" r="5.5" fill="#080A09"/><path d="M27 14.5v13l10-6.5z" fill="#080A09"/><path d="M8 38h32M14 44h20" stroke="#7BDDB0" strokeWidth="3" strokeLinecap="round"/></svg>)
}
export function Logo() {
  return <span className="inline-flex items-center gap-2.5"><LogoIcon /><span className="text-2xl font-semibold tracking-tight">resurface</span></span>
}
