import React from 'react'
import ReactDOM from 'react-dom/client'
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import './styles/index.css'
import Layout from './components/Layout'
import Discover from './pages/Discover'
import Archive from './pages/Archive'
import Review from './pages/Review'
import Studio from './pages/Studio'
import Queue from './pages/Queue'
ReactDOM.createRoot(document.getElementById('root')!).render(<React.StrictMode><BrowserRouter><Routes><Route element={<Layout />}>
  <Route index element={<Discover />} /><Route path="archive" element={<Archive />} /><Route path="review" element={<Review />} /><Route path="review/:id" element={<Review />} />
  <Route path="studio" element={<Studio />} /><Route path="studio/:id" element={<Studio />} /><Route path="queue" element={<Queue />} /></Route></Routes></BrowserRouter></React.StrictMode>)
