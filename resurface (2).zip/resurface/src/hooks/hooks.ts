import { useEffect, useState, useCallback } from 'react'
import type { QueueItem, QueueStatus } from '../types'
import { loadQueue, storeQueue } from '../services/api'
export function useAsync<T>(fn: () => Promise<T>, deps: unknown[]) {
  const [s, set] = useState<{ data?: T; loading: boolean; error?: string }>({ loading: true })
  const [n, setN] = useState(0)
  useEffect(() => { let ok = true; set(p => ({ ...p, loading: true, error: undefined }))
    fn().then(data => ok && set({ data, loading: false })).catch(e => ok && set({ loading: false, error: String(e.message ?? e) }))
    return () => { ok = false } }, [...deps, n]) // eslint-disable-line
  return { ...s, retry: () => setN(x => x + 1) }
}
export function useQueue() {
  const [queue, setQ] = useState<QueueItem[]>(loadQueue)
  const save = useCallback((fn: (q: QueueItem[]) => QueueItem[]) => setQ(q => { const n = fn(q); storeQueue(n); return n }), [])
  return { queue,
    add: (clipId: string, status: QueueStatus = 'saved', extra: Partial<QueueItem> = {}) => save(q => q.some(i => i.clipId === clipId) ? q.map(i => i.clipId === clipId ? { ...i, status, ...extra } : i) : [...q, { clipId, status, addedAt: new Date().toISOString(), ...extra }]),
    remove: (clipId: string) => save(q => q.filter(i => i.clipId !== clipId)),
    setStatus: (clipId: string, status: QueueStatus) => save(q => q.map(i => i.clipId === clipId ? { ...i, status } : i)),
    move: (clipId: string, d: number) => save(q => { const i = q.findIndex(x => x.clipId === clipId), j = i + d; if (i < 0 || j < 0 || j >= q.length) return q; const n = [...q]; [n[i], n[j]] = [n[j], n[i]]; return n }),
    has: (clipId: string) => queue.some(i => i.clipId === clipId) }
}
