// ALL DATA BELOW IS CLEARLY LABELED EXAMPLE DATA. Not real videos, quotes, or news.
import type { Topic, Video, Clip, CreatorProfile } from '../types'
export const creator: CreatorProfile = { name: 'Kameron Monet', channelUrl: 'https://www.youtube.com/@example-channel', role: 'Attorney · Founder of Social Docket', subjects: ['Creator contracts', 'FTC disclosure', 'Brand partnerships', 'Usage rights', 'AI in legal tech', 'Creator IP'] }
const ex = (t: string, d: string) => ({ title: `[Example] ${t}`, publisher: 'Example source', date: d })
export const topics: Topic[] = [
  { id: 't1', name: 'Creator Contracts', description: 'Contract terms creators are negotiating with brands and platforms.', category: 'Legal', trending: true, relevantToCreator: true, momentum: 'rising', sources: [ex('Example headline on creator contract terms', '2026-11-10')] },
  { id: 't2', name: 'Sponsored Content & FTC Rules', description: 'Disclosure requirements for sponsored posts.', category: 'Regulation', trending: false, relevantToCreator: true, momentum: 'steady', sources: [ex('Example headline on disclosure guidance', '2026-10-28')] },
  { id: 't3', name: 'AI in Legal Tech', description: 'AI tools entering legal research and contract review.', category: 'Technology', trending: true, relevantToCreator: true, momentum: 'rising', sources: [ex('Example headline on legal AI adoption', '2026-11-15'), ex('Second example legal AI headline', '2026-11-18')] },
  { id: 't4', name: 'Brand Deals & Usage Rights', description: 'Who owns and may reuse sponsored content.', category: 'Business', trending: false, relevantToCreator: true, momentum: 'emerging', sources: [ex('Example headline on usage rights', '2026-11-02')] },
  { id: 't5', name: 'Short-Form Platform Changes', description: 'Platform policy shifts affecting video creators.', category: 'Platforms', trending: true, relevantToCreator: false, momentum: 'rising', sources: [ex('Example platform policy headline', '2026-11-19')] },
]
const seg = (a: [number, string][]) => a.map(([start, text]) => ({ start, text }))
export const videos: Video[] = [
  { id: 'v1', title: '[Example] What to check before signing a brand deal', publishedAt: '2022-03-14', durationSec: 912, transcript: seg([[0, 'Example transcript: intro to brand deal basics.'], [184, 'Example transcript: payment terms and exclusivity.']]) },
  { id: 'v2', title: '[Example] Creator contract red flags', publishedAt: '2021-08-02', durationSec: 744, transcript: seg([[0, 'Example transcript: common contract red flags.'], [260, 'Example transcript: termination clauses.']]) },
  { id: 'v3', title: '[Example] Do you need to disclose that ad?', publishedAt: '2023-01-20', durationSec: 530, transcript: seg([[0, 'Example transcript: when disclosure is needed.'], [95, 'Example transcript: placement of disclosures.']]) },
  { id: 'v4', title: '[Example] Could AI do legal research?', publishedAt: '2020-11-09', durationSec: 1180, transcript: seg([[0, 'Example transcript: early thoughts on AI and law.'], [420, 'Example transcript: limits of automated research.']]) },
  { id: 'v5', title: '[Example] Who owns your sponsored video?', publishedAt: '2022-09-27', durationSec: 640, transcript: seg([[0, 'Example transcript: ownership vs license.'], [150, 'Example transcript: usage rights windows.']]) },
]
const mk = (id: string, trendId: string, videoId: string, start: number, end: number, why: string, r: number, m: number, q: number, f: number): Clip => ({
  id, trendId, videoId, start, end, why, scores: { relevance: r, momentum: m, quality: q, freshness: f },
  excerpt: '[Example excerpt] Placeholder for the transcript text of this segment.',
  hooks: ['[Example hook] This old video just became relevant again.', '[Example hook] Here is what I said before, and why it matters now.', '[Example hook] The news confirms something I covered earlier.'] })
export const clips: Clip[] = [
  mk('c1', 't1', 'v1', 184, 229, 'Segment on payment terms matches current contract-term coverage.', 92, 80, 85, 70),
  mk('c2', 't1', 'v2', 260, 312, 'Termination clauses discussion relates to the trending topic.', 88, 78, 80, 65),
  mk('c3', 't1', 'v1', 20, 61, 'Exclusivity overview supports the topic.', 75, 76, 70, 70),
  mk('c4', 't2', 'v3', 95, 140, 'Disclosure placement segment ties to recent guidance.', 90, 60, 88, 55),
  mk('c5', 't2', 'v3', 0, 38, 'Opening segment explains when disclosure applies.', 78, 58, 72, 55),
  mk('c6', 't3', 'v4', 420, 480, 'Early view on automated legal research ties to current AI coverage.', 86, 90, 74, 40),
  mk('c7', 't3', 'v4', 0, 44, 'Intro framing of AI and law.', 70, 88, 68, 40),
  mk('c8', 't4', 'v5', 150, 205, 'Usage-rights window explanation matches the topic.', 91, 55, 84, 62),
]
