# API guide for teammates
Base URL = `VITE_API_BASE_URL`. JSON in/out. Shapes are in `src/types/index.ts`. Any non-2xx response shows an error with Retry in the UI.

| Method + path | Body | Returns | Owner |
|---|---|---|---|
| GET /creator | - | CreatorProfile | YouTube ingestion |
| POST /creator/connect | {url} | CreatorProfile | YouTube ingestion |
| GET /videos | - | Video[] (transcript segments: {start seconds, text}) | YouTube ingestion |
| GET /trends | - | Topic[] (sources with url + date; trending, relevantToCreator, momentum) | You.com |
| GET /clips?trendId= | - | Clip[] (start/end seconds, excerpt, why, scores 0-100, hooks) | Matching |
| GET /clips/:id | - | Clip | Matching |
| POST /generate | GenerationRequest | {status: string} ("rendering" etc.) | Video generation |

Revival Score is computed in the frontend from `scores` (weights in `scoring.ts`). Queue and settings use localStorage; replace `loadQueue/storeQueue` in `api.ts` with endpoints when a database exists. Enable CORS on the backend for http://localhost:5173.
